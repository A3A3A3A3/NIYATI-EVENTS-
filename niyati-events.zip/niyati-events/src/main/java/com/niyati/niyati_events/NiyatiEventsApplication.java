package com.niyati.niyati_events;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NiyatiEventsApplication {

	public static void main(String[] args) {
		SpringApplication.run(NiyatiEventsApplication.class, args);
	}

}
